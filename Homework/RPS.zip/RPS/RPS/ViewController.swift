//
//  ViewController.swift
//  RPS
//
//  Created by naomi puertos on 01/10/18.
//  Copyright © 2018 naomi puertos. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
//conexiones
    @IBOutlet weak var Robot: UILabel!
    @IBOutlet weak var Estado: UILabel!
    @IBOutlet weak var rockButton: UIButton!
    @IBOutlet weak var paperButton: UIButton!
    @IBOutlet weak var scissorButton: UIButton!
    @IBOutlet weak var playAgainButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    func resetBoard(){
        Robot.text = "👾"
        Estado.text = "Rock, Paper, Scissors?"
        rockButton.isHidden = false
        rockButton.isEnabled = true
        paperButton.isHidden = false
        paperButton.isEnabled = true
        scissorButton.isHidden = false
        scissorButton.isEnabled = true
    }
    
    func play(_ playerTurn: Sing){
        rockButton.isEnabled = false
        paperButton.isEnabled = false
        scissorButton.isEnabled = false
        
        let opponent = randomSing()
        Robot.text = opponent.emoji
        let gameResult = playerTurn.takeTurn(opponent)
        
        switch gameResult {
            case.draw:
                Estado.text = "It is a draw 😑"
            case.lose:
                Estado.text = "Sorry, you lose 😜"
            case.win:
                Estado.text = "You win 😢"
            case.start:
                Estado.text = "Rock, Paper or Scissors⁉️"
            
        }
        switch playerTurn {
        case .rock:
            rockButton.isHidden = false
            paperButton.isHidden = true
            scissorButton.isHidden = true
        case.paper:
            rockButton.isHidden = true
            paperButton.isHidden = false
            scissorButton.isHidden = true
        case.scissors:
            rockButton.isHidden = true
            paperButton.isHidden = true
            scissorButton.isHidden = false
        }
        playAgainButton.isHidden = false
    }
    
    @IBAction func playAgainSelected(_ sender: Any) {
        resetBoard()
    }
    
    @IBAction func rockSelected(_ sender: Any) {
        play(Sing.rock)
    }
    
    @IBAction func paperSelected(_ sender: Any) {
        play(Sing.paper)
    }
    
    
    @IBAction func scissorsSelected(_ sender: Any) {
        play(Sing.scissors)
    }
    
}
