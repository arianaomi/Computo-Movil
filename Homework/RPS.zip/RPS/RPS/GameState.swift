//
//  GameState.swift
//  RPS
//
//  Created by naomi puertos on 02/10/18.
//  Copyright © 2018 naomi puertos. All rights reserved.
//

import Foundation
enum GameState{
    case start, win, lose, draw
}
