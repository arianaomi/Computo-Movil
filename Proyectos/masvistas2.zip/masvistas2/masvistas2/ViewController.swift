//
//  ViewController.swift
//  masvistas2
//
//  Created by naomi puertos on 10/22/18.
//  Copyright © 2018 naomi puertos. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

   //ve el estado del switch si esta encendido cambiara de visas
    @IBOutlet weak var sagueSwitch: UISwitch!
    @IBAction func yellowButtonTapped(_ sender: Any) {
        if sagueSwitch.isOn {
            performSegue(withIdentifier: "Yellow", sender: nil)
        }
    }
    @IBAction func greenButtonTapped(_ sender: Any) {
        if sagueSwitch.isOn {
            performSegue(withIdentifier: "Green", sender: nil)
        }
    }
    
}

