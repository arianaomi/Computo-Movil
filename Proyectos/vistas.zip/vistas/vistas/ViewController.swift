//
//  ViewController.swift
//  vistas
//
//  Created by naomi puertos on 10/21/18.
//  Copyright © 2018 naomi puertos. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    //para que seueda regresar el utlimo view a la principal
    @IBAction func unwindToRed(unwindSegue: UIStoryboardSegue){
    }
//para introducir un texto y que aparezca como titulo en el siguiente view
    @IBOutlet weak var textField: UITextField!
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        segue.destination.navigationItem.title = textField.text
    }
}

